# Imports the Django models.
from django.db import models
# Imports the Django vallidations error codes.
from django.core.exceptions import ValidationError

# Creates a new class called Register.
class Student (models.Model):

    # Auto Generates a numerical ID (eg: first one will be id 1) and makes it a primary key that can be used in other classes.
    student_id = models.AutoField(primary_key=True)
    # Creates a Character field named First_Name that allows you to type in a custom word instead of being auto generated.
    first_name = models.CharField(max_length=50)
    # Creates a Character field named Last_Name that allows you to type in a custom word instead of being auto generated.
    last_name = models.CharField(max_length=50)
    # Creates an Email field.
    email = models.EmailField()
    # Creates a Character field named password that allows a user to make a password 
    password = models.CharField(max_length=50, null=True)
    # Creates a Character field named confirm_password, this will be used to compare if both passwords are the same when
    # making an account.
    confirm_password = models.CharField(max_length=50, null=True)

    def clean(self):

        # Will make it so that the First_Name variable must be alphabetical not numerical.
        if not self.first_name.isalpha():
            raise ValidationError("First Name must only be letters.")
        # Will make it so that the Last_Name variable must be alphabetical not numerical.
        if not self.last_name.isalpha():
            raise ValidationError("Last Name must only be letters.")       
        # Will make it so any email added must end with "@school.nz".
        if not self.email.endswith("@school.nz"):
            raise ValidationError("Must end @school.nz.")

    # Shows the chosen variables as the name.
    def __str__(self):
        return f"{self.first_name} {self.last_name}"


# Creates a new class called Catagory.
class Catagory (models.Model):

    # Creates a Character field named Genre that allows you to type in custom words instead of being auto generated.
    Genre = models.CharField(max_length=50)
    # Creates a Character field named Fiction that allows you to type in either Fiction or Non-Fiction.
    Fiction = models.CharField(max_length=11)
    # Shows the chosen variables as the name.
    def __str__(self):
        return f"{self.Genre}, {self.Fiction}"

# Creates a new class called Book.
class Book (models.Model):

    # Auto Generates a numerical ID (eg: first one will be id 1) and makes it a primary key that can be used in other classes.
    Book_ID = models.AutoField(primary_key=True)
    # Creates a Character field named Book_Name that allows you to type in the books name.
    Name = models.CharField(max_length=50)
    # Creates a Image field which allows uploaded images to be shown in the front end.
    Img = models.ImageField(upload_to='static/images', default='images/download.jpg', blank=True, null=True)
    # Creates a Date field which allows you to get a specific date.
    Publish_Date = models.DateField()
    # Creates a Character field named Book_Name that allows you to type in the authors name.
    Author = models.CharField(max_length=50)
    # Creates a foreign key model which gets information from a previous class(gets the genre and fiction classes filled info as info here).
    Catagory = models.ForeignKey(Catagory, on_delete=models.CASCADE)
    # Creates a Interger field that can on be filled with a number 0 and above, this by default is 1.
    Copies_Available = models.IntegerField(default=1)
    # Crates a Boolean Field which adds a check box.
    Borrowed = models.BooleanField(default=False)

    # Shows the chosen variables as the name.
    def __str__(self):
        return f"{self.Name} by {self.Author}"    

# Creates a new class called Record which uses information from both Register and Book class.
class Record (models.Model):
    Borrow_id = models.AutoField(primary_key=True)
    # Creates a foreign key model which gets information from a previous class(gets the first and last name of a user).
    Student = models.ForeignKey(Student, on_delete=models.CASCADE)
    # Creates a foreign key model which gets information from a previous class(gets the books and authors name).
    Book_ID = models.ForeignKey(Book, on_delete=models.CASCADE)
    # Creates a Date field which allows you to get a specific date.
    Issue_date = models.DateField()
    # Creates a Date field which allows you to get a specific date.
    Due_date = models.DateField()
    # Creates a Date field which allows you to get a specific date.
    Return_date = models.DateField()

    # Shows the chosen variables as the name.
    def __str__(self):
        return f"{self.Student} Borrowed {self.Book_ID}"
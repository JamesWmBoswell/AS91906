from django.core.exceptions import ValidationError
from django.contrib.auth.hashers import make_password, check_password
from django.shortcuts import redirect, render
from .models import Book, Student

# Create your views here.

def home(request):
    return render(request, "home.html")

def books(request):
    books = Book.objects.all()
    return render(request, 'books.html', {'books': books})

def Register(request):

    if request.method == "POST":

        first_name = request.POST.get("first_name")
        last_name = request.POST.get("last_name")
        email = request.POST.get("email")
        password = request.POST.get("password")
        confirm_password = request.POST.get("confirm_password")


        # Check passwords match
        if password != confirm_password:
            return render(request, "register.html", {
                "errors": {
                    "password": ["Passwords do not match."]
                },
                "first_name": first_name,
                "last_name": last_name,
                "email": email,
            })
        student = Student(
            first_name=first_name,
            last_name=last_name,
            email=email,
            password=make_password(password)
        )
        try:
            # Runs your model clean() validation
            student.clean()

            # Saves into Student table
            student.save()

            # Go to login page after success
            return redirect("login")

        except ValidationError as e:

            return render(request, "register.html", {
                "errors" : e.message_dict,
                "first_name": first_name,
                "last_name": last_name,
                "email": email,
            })

    return render(request, "register.html")

def login(request):


    if request.method == "POST":
        email = request.POST.get("email")
        password = request.POST.get("password")
        try:
            # Search Student table using email
            student = Student.objects.get(email=email)
            # Check password against stored hashed password
            if check_password(password, student.password):
                # Store logged-in student details in session
                request.session['student_id'] = student.student_id
                request.session['first_name'] = student.first_name
                # Login successful
                return redirect("home")
            else:
                # Wrong password
                return render(request, "login.html", {
                    "error": "Incorrect password. Please try again."
                })
        except Student.DoesNotExist:
            # Email does not exist
            return render(request, "login.html", {
                "error": "Email is not registered."
            })
    return render(request, "login.html")

# Imports the Django models.
from django.db import models
# Imports the Django vallidations error codes.
from django.core.exceptions import ValidationError

# Creates a new class called Register.
class Register (models.Model):

    # Auto Generates a numerical ID (eg: first one will be id 1) and makes it a primary key that can be used in other classes.
    User_Id = models.AutoField(primary_key=True)

    # Creates a Character field named First_Name that allows you to type in a custom word instead of being auto generated.
    First_Name = models.CharField(max_length=50)

    # Creates a Character field named Last_Name that allows you to type in a custom word instead of being auto generated.
    Last_Name = models.CharField(max_length=50)

    # Creates an Email field.
    Email = models.EmailField()

    def clean(self):

        # Will make it so that the First_Name variable must be alphabetical not numerical.
        if not self.First_Name.isalpha():

            raise ValidationError("First Name must only be letters.")
        
        # Will make it so that the Last_Name variable must be alphabetical not numerical.
        if not self.Last_Name.isalpha():

            raise ValidationError("Last Name must only be letters.")
        
        # Will make it so any email added must end with "@school.nz".
        if not self.Email.endswith("@school.nz"):
            raise ValidationError("Must end @school.nz.")  

    # Shows the chosen variables as the name.
    def __str__(self):
        return f"{self.First_Name} {self.Last_Name}"


# Creates a new class called Catagory.
class Catagory (models.Model):

    # Creates a Character field named Genre that allows you to type in custom words instead of being auto generated.
    Genre = models.CharField(max_length=50)

    # Creates a Character field named Fiction that allows you to type in either Fiction or Non-Fiction.
    Fiction = models.CharField(max_length=11)

    # Shows the chosen variables as the name.
    def __str__(self):
        return f"{self.Genre}, {self.Fiction}"

# Creates a new class called Book.
class Book (models.Model):

    # Auto Generates a numerical ID (eg: first one will be id 1) and makes it a primary key that can be used in other classes.
    Book_ID = models.AutoField(primary_key=True)

    # Creates a Character field named Book_Name that allows you to type in the books name.
    Name = models.CharField(max_length=50)

    # Creates a Image field which allows uploaded images to be shown in the front end.
    Img = models.ImageField(upload_to='static/images', default='images/download.jpg', blank=True, null=True)

    # Creates a Date field which allows you to get a specific date.
    Publish_Date = models.DateField()

    # Creates a Character field named Book_Name that allows you to type in the authors name.
    Author = models.CharField(max_length=50)

    # Creates a foreign key model which gets information from a previous class(gets the genre and fiction classes filled info as info here).
    Catagory = models.ForeignKey(Catagory, on_delete=models.CASCADE)

    # Creates a Interger field that can on be filled with a number 0 and above, this by default is 1.
    Copies_Available = models.IntegerField(default=1)

    # Crates a Boolean Field which adds a check box.
    Borrowed = models.BooleanField(default=False)

    # Shows the chosen variables as the name.
    def __str__(self):
        return f"{self.Name} by {self.Author}"    

# Creates a new class called Record which uses information from both Register and Book class.
class Record (models.Model):
    Borrow_id = models.AutoField(primary_key=True)

    # Creates a foreign key model which gets information from a previous class(gets the first and last name of a user).
    Student = models.ForeignKey(Register, on_delete=models.CASCADE)

    # Creates a foreign key model which gets information from a previous class(gets the books and authors name).
    Book_ID = models.ForeignKey(Book, on_delete=models.CASCADE)

    # Creates a Date field which allows you to get a specific date.
    Issue_date = models.DateField()

    # Creates a Date field which allows you to get a specific date.
    Due_date = models.DateField()

    # Creates a Date field which allows you to get a specific date.
    Return_date = models.DateField()

    # Shows the chosen variables as the name.
    def __str__(self):
        return f"{self.Student} Borrowed {self.Book_ID}"
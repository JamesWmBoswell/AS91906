# Imports the Django admin information
from django.contrib import admin
# Imports the models made in "models.py" info this file
from .models import Book, Catagory, Register, Record

# shows the following classes on the admin page
admin.site.register(Book)
admin.site.register(Catagory)
admin.site.register(Register)
admin.site.register(Record)